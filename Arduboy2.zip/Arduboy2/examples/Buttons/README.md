Buttons
=======

A an example that demonstrates how to capture input from the buttons.
