#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
#include "EEPROM.h"
int EEPROM_STORAGE_SPACE_START = 0;
int EEPROM_SIZE = 1024;
int EEPROM_FILE [1024];

uint8_t EEPROMread(uint16_t address) {
  uint8_t value;
  value = EEPROM_FILE[address];
  return value;
}

void EEPROMput(uint16_t address, uint8_t value) {
	EEPROM_FILE[address]=value;
}
