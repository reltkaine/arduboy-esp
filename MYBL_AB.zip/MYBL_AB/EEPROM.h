#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
    uint8_t EEPROMread(uint16_t address);
    void EEPROMput(uint16_t address, uint8_t value);
